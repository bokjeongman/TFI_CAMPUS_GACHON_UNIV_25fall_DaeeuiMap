-- Enable realtime for accessibility_reports table
ALTER PUBLICATION supabase_realtime ADD TABLE public.accessibility_reports;